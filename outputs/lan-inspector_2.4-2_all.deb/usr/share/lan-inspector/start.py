import tkinter as tk
from dashboard import Dashboard
from lan_inspector import inspect
root=tk.Tk()
app=Dashboard(root,inspect)
root.mainloop()
