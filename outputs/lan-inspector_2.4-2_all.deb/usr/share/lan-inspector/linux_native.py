import ipaddress
import json
import socket
import subprocess

def ip_json(*args):
    return json.loads(subprocess.check_output(['ip','-j','-4',*args],timeout=5))

def adapters():
    routes=ip_json('route','show','default')
    result=[]
    for link in ip_json('addr','show','up'):
        for addr in link.get('addr_info',[]):
            if addr.get('scope')!='global':continue
            net=ipaddress.ip_interface(addr['local']+'/'+str(addr['prefixlen']))
            result.append(dict(ip=str(net.ip),name=link['ifname'],network=str(net.network),mask=str(net.netmask),interface_index=link['ifindex'],mac=link.get('address',''),gateways=[r['gateway'] for r in routes if r.get('dev')==link['ifname'] and r.get('gateway')]))
    return sorted(result,key=lambda row:not row['gateways'])

def neighbors():
    try:
        return [dict(ip=r['dst'],interface_index=socket.if_nametoindex(r['dev']),mac=r['lladdr'],source='Linux 邻居表',state='缓存') for r in ip_json('neigh','show') if r.get('lladdr') and not set(r.get('state',[])) & {'FAILED','INCOMPLETE'}],[]
    except (OSError,ValueError,subprocess.SubprocessError) as exc:
        return [],[str(exc)]
